
┌┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┐
├┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┤
├─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┤
│ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │
├─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┤
│ │ │ │ │ │ │ │ │ │U│.│S│.│ │G│R│A│P│H│I│C│S│ │C│O│M│P│A│N│Y│ │ │ │ │ │ │ │ │ │
├─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┤
│ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │
├─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┤
├─────────────────────────────────────────────────────────────────────────────┤
│                                 ~~ INFO ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ TYPEFACE     │ TX-02 Berkeley Mono™ Typeface Family                         │
│ VERSION      │ 2.002                                                        │
│ RELEASED ON  │ 2024-12-31                                                   │
│ TICKET No.   │ YX9891Y8                                                     │
│ BUILD DATE   │ 2025-07-28 16:54:11 UTC                                      │
│ FONT COUNT   │ 4 Fonts                                                      │
│ GLYPH COUNT  │ 2576 Glyphs                                                  │
│ BUILD TIME   │ 6.64 seconds                                                 │
│ SERVICE No.  │ 1Z54W5V24R                                                   │
│ SERVICE      │ TS-024 Berkeley Mono™ Standard Compiler                      │
│ SERVICE TIER │ STANDARD                                                     │
│ LICENSE No.  │ YWKP-M84Y-VZ1R-3MXR                                          │
│ LICENSE      │ LT-02 Developer Font License                                 │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ FONTS ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ TX-02-772M   │ Regular                                                      │
│ TX-02-774M   │ Oblique                                                      │
│ TX-02-7B2M   │ Bold                                                         │
│ TX-02-7B4M   │ Bold Oblique                                                 │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                         ~~ BUILD SPECIFICATIONS ~~                          │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ FC-001       │ 7                                                            │
│ FC-002       │ 7B                                                           │
│ FC-003       │ 24                                                           │
│ FC-004       │ zero.slashed                                                 │
│ FC-005       │ seven.european                                               │
│ FC-008       │ on                                                           │
│ FC-010       │ desktop_ttf                                                  │
│ FC-016       │ typeface_name                                                │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ FILES ~~                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ BerkeleyMono-Regular.ttf                                                    │
│ BerkeleyMono-Oblique.ttf                                                    │
│ BerkeleyMono-Bold.ttf                                                       │
│ BerkeleyMono-Bold-Oblique.ttf                                               │
│ README.txt                                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                         ~~ LOGS (2025-07-28 UTC) ~~                         │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ 16:54:04.819 │ INIT: Querying database for build ticket information         │
│ 16:54:04.822 │ INIT: Generated Package ID: 250728540RJR6LN5                 │
│ 16:54:04.822 │ INIT: Loading static font compiler                           │
│ 16:54:04.823 │ FEATURES: Processing FC-010: Set TTF format                  │
│ 16:54:04.921 │ FEATURES: Processing FC-008: Compile ligatures               │
│ 16:54:04.924 │ FEATURES: Processing FC-004: Target: zero, Source: zero.slas │
│ 16:54:04.924 │ FEATURES: Processing FC-005: Target: seven, Source: seven.eu │
│ 16:54:06.710 │ INTERPOLATE: Regular                                         │
│ 16:54:07.298 │ INTERPOLATE: Oblique                                         │
│ 16:54:07.345 │ INTERPOLATE: Bold                                            │
│ 16:54:07.393 │ INTERPOLATE: BoldOblique                                     │
│ 16:54:07.463 │ INTERPOLATE: Interpolating 4 instances                       │
│ 16:54:07.463 │ COMPILE: TTF, BerkeleyMono-Regular                           │
│ 16:54:08.404 │ DISK IO: Saving tmpz27310q0.ttf to ramdisk                   │
│ 16:54:08.560 │ COMPILE: TTF, BerkeleyMono-Oblique                           │
│ 16:54:09.291 │ DISK IO: Saving tmpg2mg2vpj.ttf to ramdisk                   │
│ 16:54:09.445 │ COMPILE: TTF, BerkeleyMono-Bold                              │
│ 16:54:10.172 │ DISK IO: Saving tmppuzzkkqg.ttf to ramdisk                   │
│ 16:54:10.324 │ COMPILE: TTF, BerkeleyMono-BoldOblique                       │
│ 16:54:11.288 │ DISK IO: Saving tmpi01q5bi4.ttf to ramdisk                   │
│ 16:54:11.442 │ PACKAGE: Compressing font package 250728540RJR6LN5.zip       │
│ 16:54:11.443 │ PACKAGE: Uploading font package to AWS S3                    │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ LEGAL ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ COPYRIGHT    │ Copyright 2022-2025. All Rights Reserved.                    │
│              │ Intellectual Property of U.S. Graphics, LLC.                 │
├─────────────────────────────────────────────────────────────────────────────┤
├┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┤
└┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┘